// WDXEMI001
// 2017 Prac Exam 1

#include <stdint.h>
#define STM32F051
#include "stm32f0xx.h"
#include "libs.h"

// pattern array
uint8_t myArray[] = {0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7};
//static int i = 0;
static uint8_t ledValue = 0;

int main(void) {
  // initialise all inputs and outputs
  init_LEDPB();
  init_ADC();
  int PSC = 50; // change
  int ARR = 62744; // change
  init_timer(ARR, PSC);
  display(0);
    while(1) {
      uint8_t pot1 = getPOT(1);
      setPSC(PSC+pot1);
    }
}

void TIM6_IRQ(void) {
  ledValue++;
  display(ledValue);
  reset_timer();
}

void TIM14_IRQ(void) {
  ledValue++;
  display(ledValue);
  reset_timer();
}
