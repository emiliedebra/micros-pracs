#ifndef __LIBS_H_
#define __LIBS_H_

#include <stdint.h>

//Prototypes
void libs_sample_function(void);


#endif
