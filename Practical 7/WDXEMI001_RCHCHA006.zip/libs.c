#include "libs.h"
#define STM32F051
#include "stm32f0xx.h"


void libs_sample_function(void) {
    //does nothing. 
    
}

