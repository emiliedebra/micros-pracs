#include "libs.h"
#define STM32F051
#include "stm32f0xx.h"
// declare variables
uint32_t RCC_AHBENR_IOPBEN = 0x60000;
uint32_t GPIOB_MODER_OUTPUT = 0x5555;
uint32_t PORTA_PUPDR = 0x55;
uint32_t PORTA_MODERIN = 0x28000000;
void initialise(void) {
    // enable RCC for leds and switches
    RCC->AHBENR |= RCC_AHBENR_IOPBEN;
    // set lower byte of GPIOB to outputs
    GPIOB->MODER |= GPIOB_MODER_OUTPUT;
    // configure switches
    GPIOA->PUPDR|= PORTA_PUPDR;
    GPIOA->MODER |= PORTA_MODERIN;

    // enable clock for ADC
    RCC->APB2ENR |= (0b1000000000);
    // enable ADC
    ADC1->CR |= 0b1;
    // wait for ADC ready
    while( (ADC1->ISR & (1 << 0)) == 0);
    // set ADC channel for POT 0
    ADC1->CHSELR = 0b100000;
    // set resolution to 8 bit
    ADC1->CFGR1 |= 0b010000;

}

void display(int number) {
  GPIOB->ODR = number;
}

void switch_function(void) {
  uint8_t current_state = 1; // state0
  uint8_t previous_state = 0; // state 1
  while(1) {
    uint8_t current;
    uint32_t input = GPIOA->IDR;
    previous_state = input&0b1;
    // check switch 0
    if ((previous_state == 0b0) && (current_state == 1)) {
      current = GPIOB->IDR;
      current++;
      GPIOB->ODR = current;
    }
    current_state = previous_state;

    int k = 0;
    for(k = 0; k <= 14545; k++) {
    };
  }
}

void find_min_max(uint8_t *array, int length, uint8_t **max, uint8_t **min) {
  // check max in array
  *max = array;
  *min = array;

  int i = 0;
  while(i < length) {
    if (**max < array[i]) {
      *max = &array[i];
    }
    i++;
  }

  // check min in array
  i = 0;
  while(i < length) {
    if (**min > array[i]) {
      *min = &array[i];
    }
    i++;
  }
}

// Used to check switch 0
int8_t get_switch(void) {
  // checks for switch 0 by ANDing the result with 0x1, if result = 0, button is pressed
  uint8_t result = 0;
  result = GPIOA->IDR&0b1;
  return result;
}
