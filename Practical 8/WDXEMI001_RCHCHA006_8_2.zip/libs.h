#ifndef __LIBS_H_
#define __LIBS_H_

#include <stdint.h>

//Prototypes
void initialise(void);
void display(int);
void switch_function(void);
int8_t get_switch(void);
void find_min_max(uint8_t *array, int length, uint8_t **max, uint8_t **min);
#endif
