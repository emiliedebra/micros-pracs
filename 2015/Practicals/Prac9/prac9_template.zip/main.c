// STDNUM001 STDNUM002
// Intro to micros Practical 9, 2015-10-10
#include <stdint.h>
#define STM32F051
#include "stm32f0xx.h"

// Function prototypes. (make static if possible to limit visibility to only this file)

// Global variables. (make static if possible to limit visibility to only this file)
static uint8_t led_patterns[] = {0x00, 0x81, 0xC3, 0xE7, 0xFF, 0x7E, 0x3C, 0x18};

int main(void) {
    // initialisations go here
    
    while(1) {
        // look for button presses here
    }
    return 0;
}

