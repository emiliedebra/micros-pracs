//STDNUM001 STDNUM002

#include <stdint.h>
#include "stm32f0xx.h"

#define EVER ;;

// function prototype for variable_delay
void variable_delay(void);

int main(void) {
    // enable clock for GPIOA
    RCC->AHBENR |= (1 << 17);
    // configure GPIOA pull-ups
    GPIOA->PUPDR = 0b01010101;
    // set pin connected to **POT1** (PA6) to be in analogue mode
    GPIOA->MODER |= (0b11 << 12);

    // enable clock for GPIOB
    RCC->AHBENR |= (1 << 18);
    // set GPIOB[0-7] as outputs
    GPIOB->MODER = 0b0101010101010101;

    // enable clock for ADC
    RCC->APB2ENR |= (1 << 9);
    // enable ADC
    ADC1->CR |= (1 << 0);
    // wait for ADC ready
    while( (ADC1->ISR & (1 << 0)) == 0);
    // set ADC channel for **POT1** = PA6 = channel 6
    ADC1->CHSELR = (1 << 6);
    // set rolutions/alignment if necessary. 10-bit res is advised. Done by setting bit 3 and clearing bit 4
    ADC1->CFGR1 |= (1 << 3);
    ADC1->CFGR1 &= ~(1 << 4);

    for(EVER) {
        // check if SW3 held down. If so:
        if ( (GPIOA->IDR & (1 << 3)) == 0) {
            // subtract 1 from value on LEDs
            GPIOB->ODR -= 1;
        } else {  // if not:
            // add 1 to the value on the LEDs
            GPIOB->ODR += 1;
        }
        variable_delay();
    }
    return 0;  // keep compiler happy. 
}

void variable_delay(void) {
    uint32_t delay_count_down;
    // check if SW2 is held down. If so:
    if ( (GPIOA->IDR & (1 << 2)) == 0) {
        // kick off conversion
        ADC1->CR |= (1 << 2);
        // wait for conversion complete. This can be done using a WHILE loop which keeps looping while the EOC flag is 0.
        while( (ADC1->ISR & (1 << 2)) == 0);
        // do some operation to the data available in the ADC_DR to scale it to the required timing
        delay_count_down = 73086 + (287 * ADC1->DR);
    } else {  // if not:
        // set loop iterations to a fixed amount producing a delay of 0.5 s
        delay_count_down = 365430;
    }
    // run a FOR loop, where the number of iterations is set by the value calculated above. 
    for(; delay_count_down > 0; --delay_count_down);
}
