#include <stdint.h>

#define EVER ;;

// declaration (ie: function prototype) for find_min_max function should be placed here.
void find_min_max(int8_t *array, uint32_t length, int8_t *max_ptr, int8_t *min_ptr);

// declaration for delay function here (if you decide to use a function)

void main(void) {
    // define and initialise an array of int8_t's called array
    int8_t array[] = {-4, 31, -51, 62, -45, 58, -99, 105, -6, 60, 37, 106, -106, -96, 97, 50, -116, 
        -38, 38, -52, -64, -68, 75, 117, 111, 100, 116, 11, 46, -64, -82, -74, -3, 0, 44, 64, -6, 1, -119, 123};
    // define and initialise a int8_t called min
    int8_t min = array[0];
    // define and initialsie a int8_t called max
    int8_t max = array[0];
    uint32_t delay_counter;

    // call find_min_max here, thereby getting the function to modify min and max to the correct values
    find_min_max(array, 40, &max, &min);

    // initialise pins connected to LEDs
    // provide clock to the GPIOB peripheral.
    *(uint32_t*)(0x40021000 + 0x14) |= 0x40000;
    // set PB0 - PB7 to output mode
    *(uint16_t*)(0x48000400 + 0x00) = 0b0101010101010101;

    for(EVER) {
        // display max on the LEDs
        *(uint8_t*)(0x48000400 + 0x14) = max;
        // delay for 1 s, possibly by calling delay function
        for(delay_counter = 0; delay_counter < 617856; ++delay_counter);
        // display min on the LEDs
        *(uint8_t*)(0x48000400 + 0x14) = min;
        // delay for 1 s
        for(delay_counter = 0; delay_counter < 617856; ++delay_counter);
    }
}

// define find_min_max here. Should take arguments as specified in prac sheet.
void find_min_max(int8_t *array, uint32_t length, int8_t *max_ptr, int8_t *min_ptr) {
    uint32_t counter = 0;
    // for each element in the array:
    for(; counter < length; counter++) {
        // comare the value of the element to data pointed to by max_ptr
        if(array[counter] > *max_ptr) {
            // if greater: set data at max_ptr to be the value in the array
            *max_ptr = array[counter];
        }
        // compare the value of the element to data pointed to by min_ptr
        if(array[counter] < *min_ptr) {
            // is smaller: set data at min_ptr to be the value in the array
            *min_ptr = array[counter];
        }
    }
}
